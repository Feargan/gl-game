#include "cylinder.h"

#include <cmath>
#include <windows.h>
#include <GL/GL.h>
#include <GL/GLU.h>

CCylinder::CCylinder() : ISceneObject(), m_radius(0.0), m_height(0.0)
{
}

CCylinder::~CCylinder()
{
}

void CCylinder::setRadius(double r)
{
	if(r >= 0.0)
		m_radius = r;
}

double CCylinder::getRadius() const
{
	return m_radius;
}

void CCylinder::setHeight(double h)
{
	if (h >= 0.0)
		m_height = h;
}

double CCylinder::getHeight() const
{
	return m_height;
}

void CCylinder::renderComponent() const
{
	const double diameter = m_radius * 2;
	double x, y, alpha, wysTr = 0.25;
	int i;
	glBegin(GL_TRIANGLE_FAN);
	glColor3d(1.0, 1.0, 1.0);
	glVertex3d(0, 0, 0);
	for (alpha = 0; alpha <= 2 * M_PI; alpha += M_PI / 20.0)
	{
		glColor3d(0, 0, 0);
		x = diameter / 2 * sin(alpha);
		y = diameter / 2 * cos(alpha);
		glVertex3d(x, y, 0);
	}
	glEnd();

	glBegin(GL_TRIANGLE_STRIP);
	glColor3d(0.5, 0.5, 0.5);
	for (i = 0; i < m_height / wysTr; i++)
	{
		for (alpha = 0.0; alpha <= 2 * M_PI; alpha += M_PI / 20.0)
		{
			x = diameter / 2 * sin(alpha);
			y = diameter / 2 * cos(alpha);
			//glColor3d(0, ((height / wysTr) - i) / (height / wysTr), i / (height / wysTr));
			glVertex3d(x, y, (i * wysTr));
			glVertex3d(x, y, (i * wysTr) + wysTr);
		}
	}
	glEnd();

	glBegin(GL_TRIANGLE_FAN);
	glColor3d(1.0, 1.0, 1.0);
	glVertex3d(0, 0, m_height);
	for (alpha = 0; alpha >= -2 * M_PI; alpha -= M_PI / 20.0)
	{
		glColor3d(0, 0, 0);
		x = diameter / 2 * sin(alpha);
		y = diameter / 2 * cos(alpha);
		glVertex3d(x, y, m_height);
	}
	glEnd();
}

void CCylinder::updateComponent()
{
}
