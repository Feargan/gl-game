#include "sceneobject.h"

#include <windows.h>
#include <GL/GL.h>
#include <GL/GLU.h>

ISceneObject::ISceneObject() : m_x(0.0), m_y(0.0), m_z(0.0), m_pitch(0.0), m_yaw(0.0), m_roll(0.0)
{
}

ISceneObject::~ISceneObject()
{
}

void ISceneObject::update()
{
	updateComponent();
	for (auto &p : m_children)
		p->update();
}

void ISceneObject::render() const
{
	glPushMatrix();
	glTranslated(m_x, m_y, m_z);
	glRotated(m_yaw, 0.0, 1.0, 0.0);
	glRotated(m_pitch, 1.0, 0.0, 0.0);
	glRotated(m_roll, 0.0, 0.0, 1.0);
	renderComponent();
	for (auto &p : m_children)
		p->render();
	glPopMatrix();
}

void ISceneObject::setPos(double x, double y, double z)
{
	m_x = x;
	m_y = y;
	m_z = z;
}

std::tuple<double, double, double> ISceneObject::getPos() const
{
	return { m_x, m_y, m_z };
}

void ISceneObject::setPitch(double pitch)
{
	m_pitch = pitch;
}

double ISceneObject::getPitch() const
{
	return m_pitch;
}

void ISceneObject::setYaw(double yaw)
{
	m_yaw = yaw;
}

double ISceneObject::getYaw() const
{
	return m_yaw;
}

void ISceneObject::setRoll(double roll)
{
	m_roll = roll;
}

double ISceneObject::getRoll() const
{
	return m_roll;
}
