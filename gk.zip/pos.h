#pragma once
struct CPos
{
	double m_x;
	double m_y;
	double m_z;
	double m_pitch;
	double m_yaw;
	double m_roll;
};

