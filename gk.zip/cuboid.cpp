#include "cuboid.h"

#include <windows.h>
#include <GL/GL.h>
#include <GL/GLU.h>

CCuboid::CCuboid() : m_width(0.1), m_height(0.1), m_length(0.1)
{
}

CCuboid::~CCuboid()
{
}

void CCuboid::setSize(double width, double height, double length)
{
	m_width = width;
	m_height = height;
	m_length = length;
}

std::tuple<double, double, double> CCuboid::getSize() const
{
	return { m_width, m_height, m_length };
}

void CCuboid::setColor(double r, double g, double b)
{
	m_color[0] = r;
	m_color[1] = g;
	m_color[2] = b;
}

void CCuboid::renderComponent() const
{
	glBegin(GL_TRIANGLE_STRIP);
	glColor3d(m_color[0], m_color[1], m_color[2]);
	glVertex3d(0, 0, m_width);
	glVertex3d(0, 0, 0);
	glVertex3d(m_length, 0, m_width);

	glVertex3d(m_length, 0, 0);
	glVertex3d(m_length, m_height, 0);
	glVertex3d(0, 0, 0);
	glVertex3d(0, m_height, 0);

	glVertex3d(0, 0, m_width);
	glVertex3d(0, m_height, m_width);
	glVertex3d(m_length, 0, m_width);
	glVertex3d(m_length, m_height, m_width);
	glVertex3d(m_length, 0, 0);
	glVertex3d(m_length, m_height, 0);

	glVertex3d(m_length, m_height, m_width);
	glVertex3d(0, m_height, 0);
	glVertex3d(0, m_height, m_width);
	glEnd();
}

void CCuboid::updateComponent()
{
}
