#pragma once

#include "sceneobject.h"

class CCuboid :
	public ISceneObject
{
	double m_width;
	double m_height;
	double m_length;

	double m_color[3];
public:
	CCuboid();
	virtual ~CCuboid();

	void setSize(double width, double height, double length);
	std::tuple<double, double, double> getSize() const;

	void setColor(double r, double g, double b);
protected:
	virtual void renderComponent() const override;
	virtual void updateComponent() override;
};