#pragma once

#include "sceneobject.h"

class CCylinder :
	public ISceneObject
{
	double m_radius;
	double m_height;
public:
	CCylinder();
	virtual ~CCylinder();

	void setRadius(double r);
	double getRadius() const;

	void setHeight(double h);
	double getHeight() const;
protected:
	virtual void renderComponent() const override;
	virtual void updateComponent() override;
};

